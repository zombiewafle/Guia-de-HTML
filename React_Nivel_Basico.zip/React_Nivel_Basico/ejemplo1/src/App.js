import React from 'react';
import SaludoComponent from './Componentes/SaludoComp';

function App() {
  return (
    <div>
      <SaludoComponent nombreInicial="Mundo" />
    </div>
  );
}

export default App;

