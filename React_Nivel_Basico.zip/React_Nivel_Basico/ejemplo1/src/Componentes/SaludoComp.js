import React, { useState } from 'react';

function SaludoComponent(props) {
    
  const [nombre, setNombre] = useState(props.nombreInicial);

  const cambiarNombre = () => {
    setNombre('usuario');
  };

  return (
    <div>
      <h1>Hola, {nombre}!</h1>
      <button onClick={cambiarNombre}>Cambiar Nombre</button>
    </div>
  );
}

export default SaludoComponent;
